export const GET_ERRORS = 'GET_ERRORS';
export const USER_LOADING = 'USER_LOADING';
export const SET_CURRENT_USER = 'SET_CURRENT_USER';
export const FETCH_FEED_ITEM = 'FETCH_FEED_ITEM';
export const ADD_JOB = 'ADD_JOB';
export const GET_JOB = 'GET_JOB';
export const UPDATE_JOB = 'UPDATE_JOB';
export const DELET_JOB = 'DELET_JOB';

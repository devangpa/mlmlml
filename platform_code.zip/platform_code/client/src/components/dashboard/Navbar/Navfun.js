import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useParams,
  useRouteMatch
} from "react-router-dom";

export default function Navfun() {
  let { path, url } = useRouteMatch();
  return <div></div>;
}

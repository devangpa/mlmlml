import React, { Component } from "react";

export default class Jobs extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [
        {
          title: "[URGENT] Prezi using an already created infographic",
          description:
            "I require a Prezi (Alternate tool ok if you have a preference) using an already created infographic. I just need to be able to turn into a video sequencing around the infographic with 5 additional pictures added at points in the infographic. I have a prezi account you can use.",
          budget: "300 $",
          clientName: "Hanry",
          JobPosted: "22-jun-2020"
        },
        {
          title: "Need a Angular js developer",
          description:
            "it shouuld 3 + year of experience with node js developer",
          budget: "150 $",
          clientName: "Bruse",
          JobPosted: "21-jan-2020"
        },
        {
          title: "Need a vue js developer",
          description:
            "it shouuld 3 + year of experience with node js developer",
          budget: "251 $",
          clientName: "Bendaly",
          JobPosted: "22-july-2020"
        }
      ]
    };
  }
  render() {
    return (
      <div>
        <div class="container">
          <div class="row">
            <div class="col-sm-9">
              <div class="card">
                <div class="row">
                  <div
                    class="col-sm-4"
                    style={{ marginTop: "15px", marginLeft: "10px" }}
                  >
                    <button type="button" class="btn btn-outline-primary">
                      Add Jobs
                    </button>
                  </div>
                  <div class="col-sm-4"></div>
                  <div class="col-sm-4"></div>
                </div>
              </div>
              <div class="card">
                <div class="card-header">
                  <b>Jobs</b>
                </div>
                <div class="card-body">
                  {this.state.data.map(datamap => {
                    return (
                      <div>
                        <div class="card">
                          <h5 class="card-header">{datamap.title} </h5>
                          <div class="card-body">
                            <p class="card-text">{datamap.description}</p>
                            <hr />
                            <div class="row">
                              <div class="col-sm-4">
                                <h6>
                                  Budget:<b>{datamap.budget}</b>
                                </h6>
                              </div>
                              <div class="col-sm-4">
                                <b>
                                  <i
                                    class="fa fa-calendar"
                                    aria-hidden="true"
                                  ></i>
                                  &nbsp; {datamap.JobPosted}
                                </b>
                              </div>
                              <div class="col-sm-4">
                                <b>
                                  <i class="fa fa-user" aria-hidden="true"></i>
                                  &nbsp; {datamap.clientName}
                                </b>
                              </div>
                            </div>
                          </div>
                        </div>
                        <hr />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="card-body">
                <h5>
                  <b>Suggetions</b>
                </h5>
                <hr />
                <a>
                  <h6>react js</h6>
                </a>
                <br />
                <a>
                  <h6>Node js</h6>
                </a>
                <br />
                <a>
                  <h6>Angular js</h6>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

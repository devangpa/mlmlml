import React, { Component } from "react";

export default class Connection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [
        { Name: "Devang", Connected: "20 july 2020" },
        { Name: "Krunal", Connected: "23 jun 2020" },
        { Name: "Rupesh", Connected: "13 jan 2020" },
        { Name: "Mahesh", Connected: "12 jan 2020" },
        { Name: "Harsh", Connected: "10 jan 2020" },
        { Name: "Meets", Connected: "9 jan 2020" },
        { Name: "Collsa", Connected: "8 jan 2020" },
        { Name: "Reasss", Connected: "7 jan 2020" }
      ]
    };
  }

  render() {
    return (
      <div>
        <div class="container">
          <div class="row">
            <div class="col-sm-9">
              <div class="card">
                <div class="card-header">
                  <b>Connections</b>
                </div>
                <div class="card-body">
                  {this.state.data.map(users => {
                    return (
                      <div class="card">
                        <div class="card-body">
                          <img
                            src="https://images.pexels.com/photos/4066041/pexels-photo-4066041.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                            class="rounded-circle"
                            alt="Cinque Terre"
                            width="50"
                            height="50"
                          />{" "}
                          <b>{users.Name}</b>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <button
                            type="button"
                            class="btn btn-primary"
                            style={{ marginLeft: "140px" }}
                          >
                            Chat
                          </button>
                          <hr />
                          <h6>
                            <b>Last Connected Time:{users.Connected}</b>
                          </h6>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="card">
                <div class="card-body">
                  <h5>
                    <b>Suggetions</b>
                  </h5>
                  <hr />
                  <a>
                    <h6>react js</h6>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

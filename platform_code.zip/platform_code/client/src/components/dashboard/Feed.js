import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { logoutUser } from "../../actions/authActions";
class Feed extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: []
    };
  }

  render() {
    const { user } = this.props.auth;
    console.log(user);
    return (
      <div class="container">
        <div class="row">
          <div class="col-sm-3">
            <div class="card">
              <div class="card-body">
                <img
                  src="https://images.pexels.com/photos/4066041/pexels-photo-4066041.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                  class="rounded-circle"
                  alt="Cinque Terre"
                  width="50"
                  height="50"
                  style={{ alignSelf: "center", marginLeft: "80px" }}
                />
                <hr />
                <h5 style={{ alignSelf: "center", marginLeft: "50px" }}>
                  Hey {user.name} :)
                </h5>
                <br />
                <h6 style={{ alignSelf: "center", marginLeft: "50px" }}>
                  Conection : 5{" "}
                </h6>
                <h6 style={{ alignSelf: "center", marginLeft: "50px" }}>
                  Profile View : 4{" "}
                </h6>
                <h6 style={{ alignSelf: "center", marginLeft: "50px" }}>
                  Role:{user.role}
                </h6>
              </div>
            </div>
            <div class="card">
              <div class="card-body">
                <h5>Explore</h5>
                <hr />
                <h6>
                  <a>PortFolio</a>
                </h6>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="row" style={{ marginTop: "10px" }}>
              <div class="col-sm-12">
                <input
                  type="text"
                  class="form-control form-control-sm"
                  id="colFormLabelSm"
                  placeholder="Find a Job by skills"
                />
              </div>
            </div>
            {this.state.data.map(datamap => {
              return (
                <div>
                  <div class="card">
                    <h5 class="card-header">{datamap.title}</h5>
                    <div class="card-body">
                      <p class="card-text">{datamap.description}</p>
                      <hr />
                      <div class="row">
                        <div class="col-sm-4">
                          <h6>
                            Budget:<b>{datamap.budget}</b>
                          </h6>
                        </div>
                        <div class="col-sm-4">
                          <b>
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                            &nbsp; {datamap.JobPosted}
                          </b>
                        </div>
                        <div class="col-sm-4">
                          <b>
                            <i class="fa fa-user" aria-hidden="true"></i>
                            &nbsp; {datamap.clientName}
                          </b>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr />
                </div>
              );
            })}
          </div>
          <div class="col-sm-3">
            <div class="card">
              <div class="card-body">
                <h5>
                  <b>Suggetions</b>
                </h5>
                <hr />
                <a>
                  <h6>react js</h6>
                </a>
                <br />
                <a>
                  <h6>Node js</h6>
                </a>
                <br />
                <a>
                  <h6>Angular js</h6>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
Feed.propTypes = {
  logoutUser: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth
});

export default connect(
  mapStateToProps,
  { logoutUser }
)(Feed);

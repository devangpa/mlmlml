import React from 'react';
const Footer = () => {
  return (
    <div>
      <footer class='page-footer' style={{backgroundColor: '#2979FF'}}>
        <div class='footer-copyright'>
          <div class='container'>©2020 Copyright Reserve With vorkInsta</div>
        </div>
      </footer>
    </div>
  );
};

export default Footer;

import React, { Component } from "react";

export default class Notification extends Component {
  render() {
    return (
      <div>
        <div>
          <div class="container">
            <div class="row">
              <div class="col-sm-9">
                <div class="card">
                  <div class="card-header">
                    <b>Notification</b>
                  </div>
                  <div class="card-body">
                    <div class="alert alert-success" role="alert">
                      Your Email Has been submitted
                    </div>
                    <div class="alert alert-success" role="alert">
                      This is a success alert—check it out!
                    </div>
                    <div class="alert alert-success" role="alert">
                      This is a success alert—check it out!
                    </div>
                    <div class="alert alert-success" role="alert">
                      This is a success alert—check it out!
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="card">
                  <div class="card-body">
                    <h5>
                      <b>Suggetions</b>
                    </h5>
                    <hr />
                    <a>
                      <h6>react js</h6>
                    </a>
                    <br />
                    <a>
                      <h6>Node js</h6>
                    </a>
                    <br />
                    <a>
                      <h6>Angular js</h6>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

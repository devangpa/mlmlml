import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { logoutUser } from "../../actions/authActions";
class Profile extends Component {
  render() {
    const { user } = this.props.auth;
    console.log(user.name);
    return (
      <div>
        <div>
          <div class="container">
            <div class="row">
              <div class="col-sm-9">
                <div class="card">
                  <div class="card-header">
                    <b>Profile</b>
                  </div>
                  <div class="card-body">
                    <img
                      src="https://images.pexels.com/photos/4066041/pexels-photo-4066041.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                      class="rounded-circle"
                      alt="Cinque Terre"
                      width="100"
                      height="100"
                      style={{ alignSelf: "center", marginLeft: "300px" }}
                    />
                    <hr />
                    <div class="card">
                      <div class="card-body">
                        <div style={{ marginLeft: "250px" }}>
                          <h5>
                            <b>Name : {user.name}</b>
                          </h5>
                          <br />
                          <h5>
                            <b>emailID : {user.email}</b>
                          </h5>
                          <br />
                          <h5>
                            <b>password : ***********</b>
                          </h5>
                        </div>

                        <hr />
                        <div style={{ marginLeft: "250px" }}>
                          <button
                            type="button"
                            class="btn btn-primary"
                            data-toggle="modal"
                            data-target="#exampleModalCenter"
                          >
                            Update Profile
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="card">
                  <div class="card-body">
                    <h5>
                      <b>Suggetions</b>
                    </h5>
                    <hr />
                    <a>
                      <h6>react js</h6>
                    </a>
                    <br />
                    <a>
                      <h6>Node js</h6>
                    </a>
                    <br />
                    <a>
                      <h6>Angular js</h6>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Profile.propTypes = {
  logoutUser: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth
});

export default connect(
  mapStateToProps,
  { logoutUser }
)(Profile);
